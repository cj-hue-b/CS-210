#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include <iomanip>

class ItemTracker {
private:
    std::map<std::string, int> itemFrequency;

    // Load items from input file and count frequencies
    void loadItemsFromFile(const std::string& filename) {
        std::ifstream inFile(filename);
        std::string item;
        while (inFile >> item) {
            ++itemFrequency[item];
        }
        inFile.close();
    }

    // Write frequencies to backup file
    void writeFrequencyToFile(const std::string& filename) {
        std::ofstream outFile(filename);
        for (const auto& pair : itemFrequency) {
            outFile << pair.first << " " << pair.second << std::endl;
        }
        outFile.close();
    }

public:
    // Constructor loads data and writes backup
    ItemTracker(const std::string& inputFile, const std::string& backupFile) {
        loadItemsFromFile(inputFile);
        writeFrequencyToFile(backupFile);
    }

    // Get frequency of a specific item
    int getItemFrequency(const std::string& item) {
        return itemFrequency[item];
    }

    // Print all item frequencies
    void printAllFrequencies() {
        std::cout << "\nItem Frequencies:\n";
        for (const auto& pair : itemFrequency) {
            std::cout << pair.first << " " << pair.second << std::endl;
        }
    }

    // Print histogram of item frequencies
    void printHistogram() {
        std::cout << "\nItem Frequency Histogram:\n";
        for (const auto& pair : itemFrequency) {
            std::cout << std::setw(12) << std::left << pair.first << " ";
            for (int i = 0; i < pair.second; ++i) {
                std::cout << "*";
            }
            std::cout << std::endl;
        }
    }
};

// Display menu options
void displayMenu() {
    std::cout << "\nCorner Grocer Item Tracker\n";
    std::cout << "1. Search for item frequency\n";
    std::cout << "2. Display all item frequencies\n";
    std::cout << "3. Display histogram\n";
    std::cout << "4. Exit\n";
    std::cout << "Enter your choice: ";
}

int main() {
    ItemTracker tracker("Grocery.txt", "frequency.dat");
    int choice;
    std::string item;

    do {
        displayMenu();
        std::cin >> choice;

        switch (choice) {
        case 1:
            std::cout << "Enter item name: ";
            std::cin >> item;
            std::cout << item << " was purchased " << tracker.getItemFrequency(item) << " times.\n";
            break;
        case 2:
            tracker.printAllFrequencies();
            break;
        case 3:
            tracker.printHistogram();
            break;
        case 4:
            std::cout << "Exiting program...\n";
            break;
        default:
            std::cout << "Invalid option. Please try again.\n";
        }
    } while (choice != 4);

    return 0;
}
