#include <iostream>
#include <iomanip>
#include <sstream>
using namespace std;

// Clock class handles time logic and formatting
class Clock {
private:
    int hour, minute, second;
public:
    Clock(int h = 0, int m = 0, int s = 0) : hour(h), minute(m), second(s) {}
    void addHour() { hour = (hour + 1) % 24; }
    void addMinute() { minute = (minute + 1) % 60; if (minute == 0) addHour(); }
    void addSecond() { second = (second + 1) % 60; if (second == 0) addMinute(); }

    string get24HourFormat() const {
        ostringstream oss;
        oss << setw(2) << setfill('0') << hour << ":"
            << setw(2) << setfill('0') << minute << ":"
            << setw(2) << setfill('0') << second;
        return oss.str();
    }

    string get12HourFormat() const {
        int displayHour = hour % 12;
        if (displayHour == 0) displayHour = 12;
        string period = (hour < 12) ? "AM" : "PM";
        ostringstream oss;
        oss << setw(2) << setfill('0') << displayHour << ":"
            << setw(2) << setfill('0') << minute << ":"
            << setw(2) << setfill('0') << second << " " << period;
        return oss.str();
    }
};

// ClockDisplay class handles UI and user interaction
class ClockDisplay {
private:
    Clock clock;
    void displayClocks() const {
        cout << "**************************     **************************\n";
        cout << "*     12-Hour Clock      *     *     24-Hour Clock      *\n";
        cout << "*      " << clock.get12HourFormat() << "       *     *        "
            << clock.get24HourFormat() << "        *\n";
        cout << "**************************     **************************\n\n";
    }

    void showMenu() const {
        cout << "1 - Add One Hour\n";
        cout << "2 - Add One Minute\n";
        cout << "3 - Add One Second\n";
        cout << "4 - Exit Program\n";
        cout << "Enter your choice: ";
    }

public:
    void run() {
        int choice;
        do {
            displayClocks();
            showMenu();
            cin >> choice;
            switch (choice) {
            case 1: clock.addHour(); break;
            case 2: clock.addMinute(); break;
            case 3: clock.addSecond(); break;
            case 4: cout << "Exiting program...\n"; break;
            default: cout << "Invalid choice. Try again.\n";
            }
        } while (choice != 4);
    }
};

// Main function launches the app
int main() {
    ClockDisplay app;
    app.run();
    return 0;
}
