#include <iostream>
#include <iomanip>
using namespace std;

// Class to handle investment calculations
class InvestmentCalculator {
private:
    double initialInvestment;
    double monthlyDeposit;
    double annualInterestRate;
    int numYears;

public:
    // Constructor
    InvestmentCalculator(double initInvest, double monthDep, double interestRate, int years) {
        initialInvestment = initInvest;
        monthlyDeposit = monthDep;
        annualInterestRate = interestRate;
        numYears = years;
    }

    // Display input summary
    void displayInputSummary() {
        cout << "\nInvestment Summary:\n";
        cout << "Initial Investment Amount: $" << fixed << setprecision(2) << initialInvestment << endl;
        cout << "Monthly Deposit: $" << monthlyDeposit << endl;
        cout << "Annual Interest Rate: " << annualInterestRate << "%" << endl;
        cout << "Number of Years: " << numYears << endl;
        cout << "Press any key to continue...\n";
        cin.ignore();
        cin.get();
    }

    // Calculate and display report without monthly deposits
    void calculateWithoutMonthlyDeposits() {
        double balance = initialInvestment;
        cout << "\nBalance and Interest Without Additional Monthly Deposits\n";
        cout << "Year\tYear End Balance\tYear End Earned Interest\n";

        for (int year = 1; year <= numYears; ++year) {
            double interest = balance * (annualInterestRate / 100);
            balance += interest;

            cout << year << "\t$" << fixed << setprecision(2) << balance
                << "\t\t$" << interest << endl;
        }
    }

    // Calculate and display report with monthly deposits
    void calculateWithMonthlyDeposits() {
        double balance = initialInvestment;
        cout << "\nBalance and Interest With Additional Monthly Deposits\n";
        cout << "Year\tYear End Balance\tYear End Earned Interest\n";

        for (int year = 1; year <= numYears; ++year) {
            double yearlyInterest = 0;

            for (int month = 1; month <= 12; ++month) {
                balance += monthlyDeposit;
                double monthlyInterest = balance * ((annualInterestRate / 100) / 12);
                balance += monthlyInterest;
                yearlyInterest += monthlyInterest;
            }

            cout << year << "\t$" << fixed << setprecision(2) << balance
                << "\t\t$" << yearlyInterest << endl;
        }
    }
};

// Function to validate positive input
double getPositiveDouble(string prompt) {
    double value;
    do {
        cout << prompt;
        cin >> value;
        if (value <= 0) {
            cout << "Please enter a positive number.\n";
        }
    } while (value <= 0);
    return value;
}

// Function to validate positive integer input
int getPositiveInt(string prompt) {
    int value;
    do {
        cout << prompt;
        cin >> value;
        if (value <= 0) {
            cout << "Please enter a positive integer.\n";
        }
    } while (value <= 0);
    return value;
}

// Main function
int main() {
    cout << "Welcome to the Airgead Banking App!\n";

    // Collect user input
    double initialInvestment = getPositiveDouble("Enter Initial Investment Amount: $");
    double monthlyDeposit = getPositiveDouble("Enter Monthly Deposit Amount: $");
    double annualInterestRate = getPositiveDouble("Enter Annual Interest Rate (%): ");
    int numYears = getPositiveInt("Enter Number of Years: ");

    // Create calculator object
    InvestmentCalculator calculator(initialInvestment, monthlyDeposit, annualInterestRate, numYears);

    // Display input summary
    calculator.displayInputSummary();

    // Display reports
    calculator.calculateWithoutMonthlyDeposits();
    calculator.calculateWithMonthlyDeposits();

    // Exit message
    cout << "\nThank you for using the Airgead Banking App!\n";
    return 0;
}
